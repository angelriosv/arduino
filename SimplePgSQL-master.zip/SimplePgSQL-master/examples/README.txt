Examples provided:

PgConsole - Simple PostgreSQL console
